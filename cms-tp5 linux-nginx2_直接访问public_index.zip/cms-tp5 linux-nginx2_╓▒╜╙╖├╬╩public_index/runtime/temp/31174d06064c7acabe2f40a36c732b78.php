<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"D:\thinkphp5\mytest\public/../application/admin\view\module\cp_index.html";i:1551962790;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>后台</title>
		<link rel="stylesheet" href="/static/admin/css/style.css">
	</head>
	<body>
		<div class="wrap wrap-index">
			<h1>后台首页</h1>
			<div class="box">
				<div class="box-title">欢迎访问</div>
				<div class="box-body"><p>欢迎进入内容管理系统！请从左侧选择一个操作。</p></div>
			</div>
			<div class="box">
				<div class="box-title">服务器信息</div>
				<div class="box-body">
					<p>系统环境：Apache/2.4.18&nbsp;(Win32)&nbsp;PHP/5.6.19</p>
					<p>服务器时间：2016-08-18 11:07:52</p>
					<p>MySQL版本：5.7.12</p>
					<p>文件上传限制：2M</p>
					<p>脚本执行时限：30秒</p>
				</div>
			</div>
		</div>
	</body>
</html>